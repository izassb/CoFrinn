package com.example.course.repositories;

import com.example.course.entities.LauchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LauchRepository extends JpaRepository<LauchEntity, Integer> {
}
